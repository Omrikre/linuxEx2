linux - ex1

Omri Krelman - 205800378
Bar Sela - 208223248
Shir Toren - 204812309


######  Q1:  ######
enter one stock symbol and the year after
argc: stock name, year

example:
./Q1.out FB 2020


######  Q2:  ######
enter at least one stock symbol
you can enter more. only stocks that you got data files for them
argc: stocks names

example:
./Q2.out FB GOOG IBM


######  Q3:  ######
enter at least one stock symbol
you can enter more. only stocks that you got data files for them
the file will appear at the same directory
argc: stocks names

example:
./Q3.out FB GOOG IBM